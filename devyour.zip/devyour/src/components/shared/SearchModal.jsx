import React, { useState } from "react";
import InputField from "../atoms/InputField";
import { Link } from "react-router-dom";

export default function SearchModal({ setShowSearchModal }) {

    const [username, setUsername] = useState("")
    // const [firstName, setFirstName] =useState("")
    const [userList, setUserList] = useState([])

    const fetchUsers = (evt) => {
        evt.preventDefault()
        fetch(`http://localhost:6700/api/users?username=${username}`).then(
            (res) => {
                console.log(res.body)
                 setUserList(res.body);
            }
        );
    }

    return <>
        <div className="fixed  top-0 h-screen w-full z-30 flex justify-center items-center bg-black/75">
            <div className="absolute top-10 items-center justify-center w-1/2">
                <div className='flex flex-col bg-white rounded-xl p-4'>
                    <div className="flex justify-end bg-white">
                        <svg onClick={() => setShowSearchModal(false)} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6 cursor-pointer">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                        </svg>
                    </div>

                    <form className="flex flex-col flex-grow  bg-white shadow rounded-lg mb-6 p-4" onSubmit={fetchUsers}>
                        <input className="border-1 peer block w-full appearance-none rounded-lg border border-blue bg-transparent px-2.5 pb-2.5 pt-4 text-sm text-gray-900 focus:border-pink focus:outline-none focus:ring-0" type="text" name="username" id="input-username" placeholder="Search users..." onChange={event => setUsername(event.target.value)} />

                        <div className="flex justify-end mt-2">

                            <button type="submit" className="flex items-center py-2 px-4 rounded-lg text-sm bg-blue hover:bg-pink text-white shadow-lg">Search</button>
                        </div>
                    </form>
                </div>
            </div>
            <span> Quantità utenti trovati{userList.length}</span>


            {userList.length === 0 ? <span>nessun utente presente</span>: <>

                <div className='flex flex-col w-full'>
                   
                    {//questa mappa deve generare un oggetto html con padding 4, un bordo, e un margine dall'elemento successivo di 4 px
                        //che mostri, l'immagine,  e l'usernameche sara un ancorh verso /userProfile/{idUtente}
                        userList.map(user => 
                             
                                <>
                                <div className="flex justify-between p-4 border-1 border border-blue h-1.5 w-full">
                                    <img className="" src={user.img} alt="imageProfile" />
                                  <a href="{`/userProfile/${user.id}`}">{user.username}</a> 
                                </div>
                                </>
                            
                        )}
                </div>
            </>}
        </div>


    </>
}